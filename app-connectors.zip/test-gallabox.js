const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
    const settings = await prisma.settings.findMany({
        where: { key: { in: ['GALLABOX_API_KEY', 'GALLABOX_ACCOUNT_ID', 'GALLABOX_CHANNEL_ID'] } }
    });
    const s = {};
    settings.forEach(x => s[x.key] = x.value);

    const payload = {
        channelId: s['GALLABOX_CHANNEL_ID'],
        channelType: 'whatsapp',
        recipient: { phone: '919447402340' },
        whatsapp: {
            type: 'template',
            template: {
                templateName: 'missed_call_createnextapp_3',
                language: { policy: 'deterministic', code: 'en' },
                components: [
                    {
                        type: "body",
                        parameters: [
                            { type: "text", text: "\u200B" }
                        ]
                    }
                ]
            }
        }
    };

    const res = await fetch('https://server.gallabox.com/devapi/messages/whatsapp', {
        method: 'POST',
        headers: {
            'apiKey': s['GALLABOX_API_KEY'],
            'apiSecret': s['GALLABOX_ACCOUNT_ID'],
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
    });

    console.log("Status:", res.status);
    console.log("Response:", await res.text());
}
main();
